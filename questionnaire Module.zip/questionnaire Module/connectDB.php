<?php

$lh = 'localhost'; //localhost
$db = 'coursenotes'; //dbase name
$un = 'root'; //username
$pw = 'root'; //password

?>