<footer>
    <div class="container">
        <div class="content">
            <p>&copy;<i> Copyright 2018. <a href="index.html"><b> CourseNotes</b></a>. All Rights Reserved.</i></p>
        </div>
    </div>
</footer>
</body>

</html>